#!/usr/bin/env python3
"""Verify local positivity and b(X)<=29 using exact arithmetic only.
Python >=3.9; standard library only. See the accompanying manuscript for the geometric inputs
and the proof that the parameter ranges and analytic tail are exhaustive.
The dual certificates are read from efv_nonvanishing_dual.json and
first_33_dual.json, first_35_dual.json,...,first_66_dual.json, and
first_{30,31,32,34}_integrality_duals.json and efv_small_volume_duals.json next to
this script. The latter certifies focused nonvanishing at volume <=1/31801.
Run from any directory: python3 /path/to/efv_verify_nonvanishing.py
"""
from fractions import Fraction as F
from math import gcd, lcm, ceil
from pathlib import Path
import json, time

ROOT=Path(__file__).resolve().parent
S=10000
A=1332160
W=(2626097,2448046,2149838,1750133,1451008,1087041,736627,487293,306241,112769,42854,0,0,0)
U=F(12*A-sum(W),S)
KAP=F(99,100)
D=F(37,2)*A+sum(m*w for m,w in enumerate(W,1))
TAIL=ceil((D-100*KAP*S)/(A-121*KAP*S))
RCAP=121*TAIL


def hj(r,q):
    z=[]
    while q:
        e=(r+q-1)//q;z.append(e);r,q=q,e*q-r
    return z


def cyclic_cost_numerator(r,q,ell,B):
    """Return r*S*C for a cyclic germ 1/r(1,q)."""
    qi=pow(q,-1,r);a=q+1;b=qi+1
    total=A*(r*(ell-B+3)-q-qi-3)
    sm=0
    for m,w in enumerate(W,1):
        sm+=(m*a+r-1)//r+(m*b)//r
        total+=w*(r*sm-m*(m+1)//2*(a+b))
    return total


def verify_infinite_cyclic_family():
    # Analytic tail: C > (A*ell-D)/S, r-1 <121ell-100.
    assert A-121*KAP*S>0
    assert (A-121*KAP*S)*TAIL-D+100*KAP*S>=0
    count=0
    for e in range(3,22):
      for r1 in range(1,22):
        if (e-2)*r1>=22:continue
        for q1 in ([0] if r1==1 else range(1,r1)):
          if gcd(r1,q1)!=1:continue
          left=hj(r1,q1);bl=sum(x-2 for x in left)
          inv=pow(q1,-1,r1) if r1>1 else 0
          ss=(q1*inv-1)//r1
          alpha=(e-1)*r1-q1
          for t in range(1,min(10,alpha)+1):
            low=max(r1,t);high=(RCAP-r1*t)//alpha
            if alpha>11:high=min(high,(r1*(11-t)-1)//(alpha-11))
            for n in range(low,high+1):
              if gcd(n,t)!=1 or(n==t and n!=1):continue
              h=n//t-1;v=n-(h+1)*t;tail=hj(t+v,v)
              ell=len(left)+1+h+len(tail)
              B=bl+e-2+sum(x-2 for x in tail)
              r=alpha*n+r1*t;q=((e-1)*inv-ss)*n+inv*t
              assert 0<q<r and gcd(q,r)==1 and 11*(n+r1)>r
              assert B<=19
              c=cyclic_cost_numerator(r,q,ell,B)
              assert c>0,('nonpositive local cost',e,r1,q1,t,n)
              if r>=30:
                  assert 100*c>=99*S*r*(r-1),('failed order bound',e,r1,q1,t,n)
              count+=1
    # Canonical A_{r-1}: C=(A/S)*(r-1/r) >=KAP*(r-1)>0.
    assert F(A,S)>KAP
    assert count==1694986
    return count


def solve_linear(mat,vec):
    n=len(mat);a=[[F(x) for x in row]+[F(v)] for row,v in zip(mat,vec)]
    for j in range(n):
        k=next(k for k in range(j,n) if a[k][j])
        a[j],a[k]=a[k],a[j]
        v=a[j][j];a[j]=[x/v for x in a[j]]
        for i in range(n):
            if i==j or not a[i][j]:continue
            v=a[i][j];a[i]=[x-v*y for x,y in zip(a[i],a[j])]
    return [a[i][-1] for i in range(n)]


def fork(e0,arms):
    diagonal=[e0];edges=[]
    for r,q in arms:
        last=0
        for d in hj(r,q):
            j=len(diagonal);diagonal.append(d);edges.append((last,j));last=j
    n=len(diagonal);mat=[[0]*n for _ in range(n)]
    for i,d in enumerate(diagonal):mat[i][i]=d
    for i,j in edges:mat[i][j]=mat[j][i]=-1
    b=solve_linear(mat,[d-2 for d in diagonal])
    if min(1-x for x in b)<=F(1,11):return None
    gamma=n-sum((d-2)*x for d,x in zip(diagonal,b))
    sigma=sum(F(1,r) for r,q in arms)-1
    eta=e0-sum(F(q,r) for r,q in arms)
    group=4*eta/sigma**2
    mu=gamma+1-1/group
    period=lcm(*(x.denominator for x in b))
    cs=[]
    for m in range(period):
        f=[(m+1)*x-((m+1)*x).__floor__() for x in b]
        cs.append((sum((d-2)*x for d,x in zip(diagonal,f))-sum(d*x*x for d,x in zip(diagonal,f))+2*sum(f[i]*f[j] for i,j in edges))/2)
    cost=F(A,S)*mu+sum(F(w,S)*cs[(i+1)%period] for i,w in enumerate(W))
    return dict(name=f'F({e0};{arms})',gamma=gamma,mu=mu,C=cost,period=period,cs=cs,ell=n)


def fork_bases():
    out=[]
    for e in range(3,7):
      for r in range(2,10):
        for q in range(1,r):
          if gcd(r,q)==1 and (e-1)*r-q<=10:
            z=fork(e,[(2,1),(2,1),(r,q)])
            if z is not None:out.append((z,None))
    for d in range(2,11):
      for t in range(1,d):
        if gcd(d,t)==1:
          z=fork(2,[(2,1),(2,1),(d+t,t)])
          if z is not None:out.append((z,(d,t)))
    for e in (2,3):
      for r in (3,4,5):
        for q2 in (1,2):
          for q3 in range(1,r):
            if gcd(r,q3)!=1 or(r==3 and q2>q3):continue
            z=fork(e,[(2,1),(3,q2),(r,q3)])
            if z is not None:out.append((z,None))
    assert len(out)==63
    assert all(z['C']>0 for z,_ in out)
    # D-II extensions: C_u >=C_1+(A/S)(u-1); hence u>=3 cannot satisfy C<U.
    assert min(z['C'] for z,_ in out)+2*F(A,S)>U
    # Canonical D: ell>=4, group>=8, so C>=(A/S)*(5-1/8)>U.
    assert F(A,S)*F(39,8)>U
    return out


def cyclic(r,q):
    ch=hj(r,q);ell=len(ch);B=sum(d-2 for d in ch)
    p0,p1=r,q+1;dis=[]
    for d in ch:
        dis.append(F(p1,r));p0,p1=p1,d*p1-p0
    assert p1==r
    if min(dis)<=F(1,11):return None
    qi=pow(q,-1,r)
    if q>qi:return None
    cost=F(cyclic_cost_numerator(r,q,ell,B),S*r)
    if cost>=U:return None
    gamma=ell-sum((d-2)*(1-a) for d,a in zip(ch,dis))
    mu=gamma+1-F(1,r)
    period=r//gcd(r,q+1);cs=[F(0)];sm=0
    for m in range(1,period):
        sm+=(m*(q+1)+r-1)//r+(m*(qi+1))//r
        cs.append(F(r*sm-m*(m+1)//2*(q+qi+2),r))
    assert cost==F(A,S)*mu+sum(F(w,S)*cs[(i+1)%period] for i,w in enumerate(W))
    return dict(name=f'C({r},{q})',gamma=gamma,mu=mu,C=cost,period=period,cs=cs,ell=ell)


def catalogue():
    assert U/KAP<282
    out=[]
    for r in range(2,283):
      for q in range(1,r):
        if gcd(r,q)!=1:continue
        z=cyclic(r,q)
        if z is not None:out.append(z)
    cyclic_n=len(out)
    for z,params in fork_bases():
        if z['C']<U:out.append(z)
        if params is not None:
            d,t=params;zz=fork(2,[(2,1),(2,1),(2*d+t,d+t)])
            if zz is not None and zz['C']<U:out.append(zz)
    assert cyclic_n==2063 and len(out)==2114
    assert max(g['period'] for g in out if g['name'].startswith('F'))<=27
    return out


def verify_dual(G):
    cert=json.loads((ROOT/'efv_nonvanishing_dual.json').read_text())
    M=cert['B'];y=list(map(F,cert['y']));z=list(map(F,cert['z']));d=F(cert['delta'])
    assert M==66 and len(y)==M-1 and len(z)==3 and all(a>=0 for a in z) and d>=0
    vals=[]
    for g in G:
        cs=[g['cs'][m%g['period']] for m in range(M+1)];c1=cs[1]
        u=[c-m*(m+1)//2*c1 for m,c in enumerate(cs)]
        assert all(v.denominator==1 for v in u)
        E=[u[2]]+[u[m+1]-2*u[m]+u[m-1] for m in range(2,M)]
        UB=[c1,g['gamma']-c1,g['mu']-F(4,3)*c1]
        val=sum(a*b for a,b in zip(y,E))+sum(a*b for a,b in zip(z,UB))+d*g['C']
        assert val>=0,(g['name'],val)
        vals.append(val)
    rhs=[F(2)]+[F(1)]*(M-2)
    upper=[F(-1),F(10),F(40,3)]
    total=sum(a*b for a,b in zip(y,rhs))+sum(a*b for a,b in zip(z,upper))+d*U
    assert total<0
    assert total==F(cert['constant']) and min(vals)==F(cert['min_coefficient'])
    return dict(B=M,number_of_types=len(G),min_coefficient=str(min(vals)),contradictory_upper_bound=str(total))


def verify_first_section_duals(G):
    """Verify direct first-degree exclusions and integral-dimension chains.

    Rows are expanded from definitions, denominator-cleared, and checked on
    every catalogue column. A chain may use a zero only after a preceding
    certificate excludes P_n>=1. Since P_n is a nonnegative integer, this
    proves that the new zero is valid. The final certificate has no branch.
    """
    M=220;Q=[m*(m+1)//2 for m in range(M+1)]
    prepared=[]
    for g in G:
        c1=g['cs'][1%g['period']]
        u=[g['cs'][m%g['period']]-Q[m]*c1 for m in range(M+1)]
        assert all(v.denominator==1 for v in u)
        prepared.append(([int(v) for v in u],c1,g['gamma'],g['mu'],g['C']))

    def check(cert,first,known_zeros=(),forbidden=None,volume_ceiling=None):
        assert cert['first']==first and cert['max_degree']==M
        wu=[F(0)]*(M+1);wc=F(0);wg=F(0);wm=F(0)
        wcost=F(cert['cost_correction']);assert wcost>=0
        rhs=wcost*U
        for row in cert['rows']:
            label=row['label'];t=F(row['multiplier']);assert t>=0
            kind=label[0]
            if kind=='eq':
                j,sgn=label[1:];assert 0<=j<first-2 and sgn in (-1,1)
                t*=sgn
                if j==0:wu[2]+=t;rhs+=2*t
                else:
                    n=j+1;wu[n+1]+=t;wu[n]-=2*t;wu[n-1]+=t;rhs+=t
            elif kind=='base':
                j=label[1];assert j in (0,1,2)
                if j==0:wc+=t;rhs-=t
                elif j==1:wg+=t;wc-=t;rhs+=10*t
                else:wm+=t;wc-=F(4,3)*t;rhs+=F(40,3)*t
            elif kind=='nonneg':
                n=label[1];assert first<=n<=M
                wu[n]-=t/Q[n];rhs+=t*F(1-Q[n],Q[n])
            elif kind=='first':
                assert label[1]==first;wu[first]-=t/Q[first];rhs-=t
            elif kind=='shift':
                n,m=label[1:];assert m==first and 1<=n<=M-m
                dq=Q[n+m]-Q[n];wu[n+m]-=t/dq;wu[n]+=t/dq;rhs-=t
            elif kind=='zero':
                n,sgn=label[1:];assert n in known_zeros and sgn in (-1,1)
                wu[n]+=sgn*t/Q[n];rhs+=sgn*t*F(Q[n]-1,Q[n])
            elif kind=='nonzero':
                n=label[1];assert n==forbidden and first<n<=M
                wu[n]-=t/Q[n];rhs-=t
            elif kind=='volume_ceiling':
                assert volume_ceiling is not None and F(label[1])==volume_ceiling
                wc-=t;rhs+=t*(1+volume_ceiling)
            elif kind=='cost':
                wcost+=t;rhs+=t*U
            else:raise AssertionError(('unknown row type',label))
        denominator=lcm(*(x.denominator for x in wu+[wc,wg,wm,wcost]))
        int_u=[(i,int(v*denominator)) for i,v in enumerate(wu) if v]
        int_c,int_g,int_m,int_cost=[int(x*denominator) for x in (wc,wg,wm,wcost)]
        vals=[]
        for g,(u,c1,gamma,mu,cost) in zip(G,prepared):
            val=F(sum(w*u[i] for i,w in int_u))+int_c*c1+int_g*gamma+int_m*mu+int_cost*cost
            assert val>=0,('first-degree certificate failed',first,forbidden,g['name'],val)
            vals.append(val/denominator)
        assert rhs<0 and rhs==F(cert['constant']) and min(vals)==F(cert['min_coefficient'])
        return dict(first=first,forbidden_nonzero=forbidden,active_rows=len(cert['rows']),min_coefficient=str(min(vals)),contradictory_upper_bound=str(rhs))

    direct=[]
    for first in [33]+list(range(35,67)):
        cert=json.loads((ROOT/f'efv_first_{first}_dual.json').read_text())
        direct.append(check(cert,first))
    chains=[]
    for first in (30,31,32,34):
        chain=json.loads((ROOT/f'efv_first_{first}_integrality_duals.json').read_text())
        assert chain['first']==first and chain['max_degree']==M
        zeros=chain['forced_zero_degrees'];certs=chain['certificates']
        assert len(certs)==len(zeros)+1 and len(set(zeros))==len(zeros)
        known=[];results=[]
        for n,cert in zip(zeros,certs[:-1]):
            assert first<n<=M and cert['forbidden_nonzero']==n
            results.append(check(cert,first,known,n));known.append(n)
        assert certs[-1]['forbidden_nonzero'] is None
        results.append(check(certs[-1],first,known))
        chains.append(dict(first=first,forced_zero_degrees=zeros,certificates=results))
    assert len(direct)==33 and sum(len(c['certificates']) for c in chains)==34
    small=[]
    certificates=json.loads((ROOT/'efv_small_volume_duals.json').read_text())
    assert [c['first'] for c in certificates]==list(range(12,30))
    for cert in certificates:
        cap=F(cert['volume_ceiling']);assert cap==F(1,31801)
        small.append(check(cert,cert['first'],volume_ceiling=cap))
    return direct,chains,small


def main():
    start=time.time()
    count=verify_infinite_cyclic_family()
    G=catalogue()
    result=verify_dual(G)
    result['preliminary_bound']=result.pop('B')
    result['B']=29
    result['first_degree_exclusions'],result['integrality_chains'],result['small_volume_exclusions']=verify_first_section_duals(G)
    result['small_volume_general_b_bound']=13
    result['small_volume_high_mld_b_bound']=11
    result['small_volume_ceiling']='1/31801'
    low_mld_volumes=list(map(F,['2/10465','9/37835','1/5083','4/13685','2/17043','127/596505','16/61617','127/596505','2/17043','2/36855','1/21385','2/14053','1/10465','1/10465','1/3115','6/26611','6/26611','1/3713','3/23621','8/35945','8/35945','3/23621','3/23621','3/23621','1/3289']))
    # The geometric classification is LS23 Theorem1.9/Table8; check its numerical minimum.
    assert len(low_mld_volumes)==25 and min(low_mld_volumes)==F(1,21385)>F(1,31801)
    result['classified_low_mld_minimum_volume']='1/21385'
    result['exceptional_small_volume_b_bound']=11
    result.update(cyclic_parameter_checks=count,tail_length=TAIL,r_cap=RCAP,cyclic_order_bound=282,cost_upper_bound=str(U),elapsed_seconds=round(time.time()-start,3),status='all exact assertions passed')
    print(json.dumps(result,indent=2))
    (ROOT/'efv_nonvanishing_result.json').write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':main()
