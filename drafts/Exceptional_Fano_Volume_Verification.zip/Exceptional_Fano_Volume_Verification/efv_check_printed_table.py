#!/usr/bin/env python3
"""Check all printed integer coefficients and an arithmetic control basket.
Python >=3.9, standard library only. Run without Python's -O option.
"""
from pathlib import Path
from fractions import Fraction as F
import json
from efv_local_catalogue import catalogue
ROOT=Path(__file__).resolve().parent
tab=json.loads((ROOT/'efv_printed_table.json').read_text())
cert=json.loads((ROOT/'efv_sharp_volume_dual.json').read_text())
D=int(tab['denominator']);Q=lambda n:F(n*(n+1),2)
assert len(tab['rows'])==len(cert['rows'])==66
assert len(tab['equalities'])==len(cert['equalities'])==9
for row,old in zip(tab['rows'],cert['rows']):
    assert row['label']==old['label']
    lab=row['label'];n=lab[1]
    scale=Q(n) if lab[0]!='shift' else Q(n+lab[2])-Q(n)
    assert F(int(row['numerator']),D)==F(old['multiplier'])/scale>0
for row,old in zip(tab['equalities'],cert['equalities']):
    assert row['degree']==old['degree']
    assert F(int(row['numerator']),D)==F(old['multiplier'])
G=catalogue()
def a(g,n):return g['cs'][n%g['period']]
def u(g,n):return a(g,n)-Q(n)*a(g,1)
def row_value(g,lab):
    kind,n=lab[:2]
    return u(g,n+lab[2])-u(g,n) if kind=='shift' else u(g,n)
def row_rhs(lab):
    kind,n=lab[:2]
    if kind=='shift':return Q(n+lab[2])-Q(n)
    return Q(n)-1 if kind=='nonnegative' else Q(n)
res=[]
for g in G:
    val=-D*a(g,1)
    val-=sum(int(r['numerator'])*row_value(g,r['label']) for r in tab['rows'])
    val-=sum(int(r['numerator'])*u(g,r['degree']) for r in tab['equalities'])
    assert val>=0,(g['name'],val)
    res.append(val)
constant=sum(int(r['numerator'])*row_rhs(r['label']) for r in tab['rows'])
constant+=sum(int(r['numerator'])*(Q(r['degree'])-1) for r in tab['equalities'])
assert constant==D*F(31802,31801)
names={'C(49,17)','C(59,42)','C(22,13)'}
control=[g for g in G if g['name'] in names]
assert len(control)==3
V=-1-sum(a(g,1) for g in control)
rho=10-V-sum(g['gamma'] for g in control)
P=lambda n:1+Q(n)*V+sum(a(g,n) for g in control)
assert V==F(1,31801) and rho==2
assert [P(n) for n in range(1,12)]==[0]*10+[1]
assert all(sum(row_value(g,r['label']) for g in control)==row_rhs(r['label']) for r in tab['rows'])
assert all(res[i]==0 for i,g in enumerate(G) if g['name'] in names)
result={'status':'ALL PRINTED COEFFICIENTS AND CONTROL CHECKS PASSED',
        'common_denominator':str(D),'inequality_rows':66,'equality_rows':9,
        'local_types':len(G),'zero_residuals':sum(v==0 for v in res),
        'objective_constant':str(F(constant,D)),
        'control_volume':str(V),'control_picard_number':str(rho),
        'control_P_1_to_11':[str(P(n)) for n in range(1,12)]}
(ROOT/'efv_printed_table_result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
