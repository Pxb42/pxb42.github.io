#!/usr/bin/env python3
"""Rebuild the complete catalogue and verify V >= 1/31801 exactly.
Run: python3 /path/to/efv_verify_sharp.py
Python >=3.9, standard library only; no solver and no input catalogue.
"""
from fractions import Fraction as F
from pathlib import Path
import json,time
from efv_local_catalogue import verify_infinite_cyclic_family, fork_bases, catalogue, A,W,U,TAIL,RCAP,RBOUND
ROOT=Path(__file__).resolve().parent
start=time.time()
count=verify_infinite_cyclic_family()
fb=fork_bases();G=catalogue()
assert len(G)==2121
assert sum(g['name'].startswith('C') for g in G)==2067
cert=json.loads((ROOT/'efv_sharp_volume_dual.json').read_text())
assert cert['first']==11 and cert['max_degree']==220
assert F(cert['lower_bound'])==F(1,31801)
M=cert['max_degree'];Q=[F(n*(n+1),2) for n in range(M+1)]
c1=[g['cs'][1%g['period']] for g in G]
u=[[g['cs'][n%g['period']]-Q[n]*c for g,c in zip(G,c1)] for n in range(M+1)]
res=[-c for c in c1];constant=F(0)
# For A n <= b, lambda>=0: objective >= -lambda*b + y*e
# if objective + lambda*A - y*E is coefficientwise nonnegative.
for item in cert['rows']:
 lab=item['label'];lam=F(item['multiplier']);assert lam>0
 if lab[0]=='nonnegative':
  n=lab[1];assert 11<=n<=M
  row=[-x/Q[n] for x in u[n]];rhs=(1-Q[n])/Q[n]
 elif lab[0]=='first':
  n=lab[1];assert n==11
  row=[-x/Q[n] for x in u[n]];rhs=F(-1)
 elif lab[0]=='shift':
  n,d=lab[1:];assert d==11 and n>=1 and n+d<=M
  dq=Q[n+d]-Q[n]
  row=[-(x-y)/dq for x,y in zip(u[n+d],u[n])];rhs=F(-1)
 else:
  raise AssertionError(('unexpected row',lab))
 res=[x+lam*a for x,a in zip(res,row)];constant-=lam*rhs
assert [item['degree'] for item in cert['equalities']]==list(range(2,11))
for item in cert['equalities']:
 n=item['degree'];y=F(item['multiplier'])
 res=[x-y*a for x,a in zip(res,u[n])];constant+=y*(Q[n]-1)
assert min(res)>=0
assert constant==F(31802,31801)==F(cert['constant'])
assert min(res)==F(cert['min_coefficient'])
zero=[g['name'] for g,x in zip(G,res) if not x]
assert zero==cert['zero_germs']
assert len(zero)==308
result=dict(status='ALL EXACT CHECKS PASSED',theorem='mld>1/11 and b=11 imply V>=1/31801 for exceptional del Pezzo surfaces',A=A,W=W,budget=str(U),analytic_tail=TAIL,cyclic_search_cap=RCAP,cyclic_order_bound=RBOUND,cyclic_parameter_checks=count,cyclic_types=2067,fork_types=54,local_types=len(G),inequality_dual_rows=len(cert['rows']),equality_dual_rows=len(cert['equalities']),exact_objective_bound=str(constant),volume_lower_bound='1/31801',zero_columns=len(zero),smallest_positive_column=str(min(x for x in res if x>0)),elapsed_seconds=time.time()-start)
(ROOT/'efv_sharp_result.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
