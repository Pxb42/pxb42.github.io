#!/usr/bin/env python3
"""Exact local catalogue for exceptional del Pezzo surfaces with
mld>1/11 and P_1=...=P_10=0. Standard library only.
The accompanying paper proves completeness of the parameter ranges.
"""
from fractions import Fraction as F
from math import gcd, lcm, ceil
from pathlib import Path
import json, time

ROOT=Path(__file__).resolve().parent
S=10000
A=1328286
W=(2646679, 2502711, 2225722, 1676569, 1489733, 1041192, 678175, 458179, 302742, 39074, 0, 0, 0, 0)
U=F(12*A-sum(W),S)
KAP=F(99,100)
D=F(37,2)*A+sum(m*w for m,w in enumerate(W,1))
TAIL=ceil((D-100*KAP*S)/(A-121*KAP*S))
RCAP=121*TAIL
RBOUND=ceil(U/KAP)


def hj(r,q):
    z=[]
    while q:
        e=(r+q-1)//q;z.append(e);r,q=q,e*q-r
    return z


def cyclic_cost_numerator(r,q,ell,B):
    """Return r*S*C for a cyclic germ 1/r(1,q)."""
    qi=pow(q,-1,r);a=q+1;b=qi+1
    total=A*(r*(ell-B+3)-q-qi-3)
    sm=0
    for m,w in enumerate(W,1):
        sm+=(m*a+r-1)//r+(m*b)//r
        total+=w*(r*sm-m*(m+1)//2*(a+b))
    return total


def verify_infinite_cyclic_family():
    # Analytic tail: C > (A*ell-D)/S, r-1 <121ell-100.
    assert A-121*KAP*S>0
    assert (A-121*KAP*S)*TAIL-D+100*KAP*S>=0
    count=0
    for e in range(3,22):
      for r1 in range(1,22):
        if (e-2)*r1>=22:continue
        for q1 in ([0] if r1==1 else range(1,r1)):
          if gcd(r1,q1)!=1:continue
          left=hj(r1,q1);bl=sum(x-2 for x in left)
          inv=pow(q1,-1,r1) if r1>1 else 0
          ss=(q1*inv-1)//r1
          alpha=(e-1)*r1-q1
          for t in range(1,min(10,alpha)+1):
            low=max(r1,t);high=(RCAP-r1*t)//alpha
            if alpha>11:high=min(high,(r1*(11-t)-1)//(alpha-11))
            for n in range(low,high+1):
              if gcd(n,t)!=1 or(n==t and n!=1):continue
              h=n//t-1;v=n-(h+1)*t;tail=hj(t+v,v)
              ell=len(left)+1+h+len(tail)
              B=bl+e-2+sum(x-2 for x in tail)
              r=alpha*n+r1*t;q=((e-1)*inv-ss)*n+inv*t
              assert 0<q<r and gcd(q,r)==1 and 11*(n+r1)>r
              assert B<=19
              c=cyclic_cost_numerator(r,q,ell,B)
              assert c>0,('nonpositive local cost',e,r1,q1,t,n)
              if r>=30:
                  assert 100*c>=99*S*r*(r-1),('failed order bound',e,r1,q1,t,n)
              count+=1
    # Canonical A_{r-1}: C=(A/S)*(r-1/r) >=KAP*(r-1)>0.
    assert F(A,S)>KAP
    return count


def solve_linear(mat,vec):
    n=len(mat);a=[[F(x) for x in row]+[F(v)] for row,v in zip(mat,vec)]
    for j in range(n):
        k=next(k for k in range(j,n) if a[k][j])
        a[j],a[k]=a[k],a[j]
        v=a[j][j];a[j]=[x/v for x in a[j]]
        for i in range(n):
            if i==j or not a[i][j]:continue
            v=a[i][j];a[i]=[x-v*y for x,y in zip(a[i],a[j])]
    return [a[i][-1] for i in range(n)]


def fork(e0,arms):
    diagonal=[e0];edges=[]
    for r,q in arms:
        last=0
        for d in hj(r,q):
            j=len(diagonal);diagonal.append(d);edges.append((last,j));last=j
    n=len(diagonal);mat=[[0]*n for _ in range(n)]
    for i,d in enumerate(diagonal):mat[i][i]=d
    for i,j in edges:mat[i][j]=mat[j][i]=-1
    b=solve_linear(mat,[d-2 for d in diagonal])
    if min(1-x for x in b)<=F(1,11):return None
    gamma=n-sum((d-2)*x for d,x in zip(diagonal,b))
    sigma=sum(F(1,r) for r,q in arms)-1
    eta=e0-sum(F(q,r) for r,q in arms)
    group=4*eta/sigma**2
    mu=gamma+1-1/group
    period=lcm(*(x.denominator for x in b))
    cs=[]
    for m in range(period):
        f=[(m+1)*x-((m+1)*x).__floor__() for x in b]
        cs.append((sum((d-2)*x for d,x in zip(diagonal,f))-sum(d*x*x for d,x in zip(diagonal,f))+2*sum(f[i]*f[j] for i,j in edges))/2)
    cost=F(A,S)*mu+sum(F(w,S)*cs[(i+1)%period] for i,w in enumerate(W))
    return dict(name=f'F({e0};{arms})',gamma=gamma,mu=mu,C=cost,period=period,cs=cs,ell=n)


def fork_bases():
    out=[]
    for e in range(3,7):
      for r in range(2,10):
        for q in range(1,r):
          if gcd(r,q)==1 and (e-1)*r-q<=10:
            z=fork(e,[(2,1),(2,1),(r,q)])
            if z is not None:out.append((z,None))
    for d in range(2,11):
      for t in range(1,d):
        if gcd(d,t)==1:
          z=fork(2,[(2,1),(2,1),(d+t,t)])
          if z is not None:out.append((z,(d,t)))
    for e in (2,3):
      for r in (3,4,5):
        for q2 in (1,2):
          for q3 in range(1,r):
            if gcd(r,q3)!=1 or(r==3 and q2>q3):continue
            z=fork(e,[(2,1),(3,q2),(r,q3)])
            if z is not None:out.append((z,None))
    assert len(out)==63
    assert all(z['C']>0 for z,_ in out)
    # D-II extensions: C_u >=C_1+(A/S)(u-1); hence u>=3 cannot satisfy C<U.
    assert min(z['C'] for z,_ in out)+2*F(A,S)>U
    # Canonical D: ell>=4, group>=8, so C>=(A/S)*(5-1/8)>U.
    assert F(A,S)*F(39,8)>U
    return out


def cyclic(r,q):
    ch=hj(r,q);ell=len(ch);B=sum(d-2 for d in ch)
    p0,p1=r,q+1;dis=[]
    for d in ch:
        dis.append(F(p1,r));p0,p1=p1,d*p1-p0
    assert p1==r
    if min(dis)<=F(1,11):return None
    qi=pow(q,-1,r)
    if q>qi:return None
    cost=F(cyclic_cost_numerator(r,q,ell,B),S*r)
    if cost>=U:return None
    gamma=ell-sum((d-2)*(1-a) for d,a in zip(ch,dis))
    mu=gamma+1-F(1,r)
    period=r//gcd(r,q+1);cs=[F(0)];sm=0
    for m in range(1,period):
        sm+=(m*(q+1)+r-1)//r+(m*(qi+1))//r
        cs.append(F(r*sm-m*(m+1)//2*(q+qi+2),r))
    assert cost==F(A,S)*mu+sum(F(w,S)*cs[(i+1)%period] for i,w in enumerate(W))
    return dict(name=f'C({r},{q})',gamma=gamma,mu=mu,C=cost,period=period,cs=cs,ell=ell)


def catalogue():
    assert RBOUND>=30
    out=[]
    for r in range(2,RBOUND+1):
      for q in range(1,r):
        if gcd(r,q)!=1:continue
        z=cyclic(r,q)
        if z is not None:out.append(z)
    cyclic_n=len(out)
    for z,params in fork_bases():
        if z['C']<U:out.append(z)
        if params is not None:
            d,t=params;zz=fork(2,[(2,1),(2,1),(2*d+t,d+t)])
            if zz is not None and zz['C']<U:out.append(zz)
    print("catalogue counts",cyclic_n,len(out)-cyclic_n,flush=True)
    assert max(g['period'] for g in out if g['name'].startswith('F'))<=27
    return out
