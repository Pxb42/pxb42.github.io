"""Independent residue/graph verification of the sharp-volume dual.
Standard library only; local corrections are recomputed independently.
"""
import ast,json,sys,time
from pathlib import Path
from fractions import Fraction as F
from math import gcd,lcm
ROOT=Path(__file__).resolve().parent
from efv_local_catalogue import A,W,S,U,cyclic_cost_numerator,catalogue

def inverse_and_det(matrix):
    n=len(matrix)
    a=[[F(v) for v in row]+[F(int(i==j)) for j in range(n)] for i,row in enumerate(matrix)]
    det=F(1)
    for i in range(n):
        k=next(k for k in range(i,n) if a[k][i])
        if k!=i:a[k],a[i]=a[i],a[k];det=-det
        pivot=a[i][i];det*=pivot;a[i]=[v/pivot for v in a[i]]
        for j in range(n):
            if j==i or not a[j][i]:continue
            mult=a[j][i];a[j]=[x-mult*y for x,y in zip(a[j],a[i])]
    return [row[n:] for row in a],det

def hj(r,q):
    out=[]
    while q:
        w=-(-r//q);out.append(w);r,q=q,w*q-r
    return out

def cyclic_independent(r,q):
    diag=hj(r,q);a0,a1=r,q+1;dis=[]
    for w in diag:
        dis.append(F(a1,r));a0,a1=a1,w*a1-a0
    assert a1==r
    if min(dis)<=F(1,11):return None
    gamma=len(diag)-sum((w-2)*(1-a) for w,a in zip(diag,dis))
    mu=gamma+1-F(1,r)
    qi=pow(q,-1,r);cum=[0]
    for j in range(1,r):cum.append(cum[-1]+r-1-2*(j*qi%r))
    period=r//gcd(r,q+1)
    cs=[F(cum[m*(q+1)%r],2*r) for m in range(period)]
    cost=F(A,S)*mu+sum(F(w,S)*cs[m%period] for m,w in enumerate(W,1))
    assert cost==F(cyclic_cost_numerator(r,q,len(diag),sum(w-2 for w in diag)),S*r)
    return gamma,mu,cs,cost

def fork_independent(name):
    e0,rest=name[2:-1].split(';');arms=ast.literal_eval(rest)
    diag=[int(e0)];edges=[]
    for r,q in arms:
        prev=0
        for w in hj(r,q):
            j=len(diag);diag.append(w);edges.append((prev,j));prev=j
    mat=[[0]*len(diag) for _ in diag]
    for i,w in enumerate(diag):mat[i][i]=w
    for i,j in edges:mat[i][j]=mat[j][i]=-1
    inv,_=inverse_and_det(mat);kv=[w-2 for w in diag]
    b=[sum(x*y for x,y in zip(row,kv)) for row in inv]
    assert min(1-x for x in b)>F(1,11)
    gamma=len(diag)-sum(x*y for x,y in zip(kv,b))
    eta=F(e0)-sum(F(q,r) for r,q in arms)
    sigma=sum(F(1,r) for r,q in arms)-1
    group=4*eta/sigma**2
    mu=gamma+1-1/group
    per=lcm(*(x.denominator for x in b));cs=[]
    for m in range(per):
        f=[(m+1)*x-((m+1)*x).__floor__() for x in b]
        quad=sum(f[i]*mat[i][j]*f[j] for i in range(len(diag)) for j in range(len(diag)))
        cs.append((sum(x*y for x,y in zip(kv,f))-quad)/2)
    cost=F(A,S)*mu+sum(F(w,S)*cs[m%per] for m,w in enumerate(W,1))
    return gamma,mu,cs,cost

def main():
    start=time.time();G=catalogue();prep=[]
    for g in G:
        if g['name'].startswith('C'):
            r,q=map(int,g['name'][2:-1].split(','));values=cyclic_independent(r,q)
        else:values=fork_independent(g['name'])
        gamma,mu,cs,cost=values;assert cost>0 and cost<U
        assert gamma==F(g['gamma']) and mu==F(g['mu']) and cost==F(g['C'])
        assert cs==list(map(F,g['cs']))
        c1=cs[1%len(cs)];u=[cs[m%len(cs)]-m*(m+1)//2*c1 for m in range(221)]
        assert all(x.denominator==1 for x in u)
        prep.append((c1,list(map(int,u))))
    cert=json.load(open(ROOT/'efv_sharp_volume_dual.json'))
    assert cert['first']==11 and cert['max_degree']==220
    ucoef=[F(0)]*221;rhs=F(0)
    for row in cert['rows']:
        typ,*args=row['label'];t=F(row['multiplier']);assert t>=0
        if typ=='nonnegative':
            n=args[0];assert n>=11
            Q=n*(n+1)//2;ucoef[n]-=t/Q;rhs-=t*F(1-Q,Q)
        elif typ=='first':
            n=args[0];assert n==11
            Q=n*(n+1)//2;ucoef[n]-=t/Q;rhs+=t
        elif typ=='shift':
            n,m=args;assert m==11 and 1<=n<=209
            Q=(n+m)*(n+m+1)//2-n*(n+1)//2
            ucoef[n]+=t/Q;ucoef[n+m]-=t/Q;rhs+=t
        else:raise AssertionError(typ)
    assert [x['degree'] for x in cert['equalities']]==list(range(2,11))
    for row in cert['equalities']:
        n=row['degree'];t=F(row['multiplier']);ucoef[n]-=t;rhs+=t*(n*(n+1)//2-1)
    den=lcm(*(x.denominator for x in ucoef))
    ucoef=[(i,int(v*den)) for i,v in enumerate(ucoef) if v]
    residual=[-c1+F(sum(u[i]*v for i,v in ucoef),den) for c1,u in prep]
    assert min(residual)>=0 and rhs==F(31802,31801)
    assert min(residual)==F(cert['min_coefficient']) and rhs==F(cert['constant'])
    zeros=[g['name'] for g,v in zip(G,residual) if v==0]
    assert zeros==cert['zero_germs']
    result=dict(status='independent exact audit passed',local_types=len(G),cyclic_types=sum(g['name'].startswith('C') for g in G),fork_types=sum(g['name'].startswith('F') for g in G),positive_multipliers=len(cert['rows']),signed_equalities=len(cert['equalities']),minimum_residual=str(min(residual)),zero_residual_types=len(zeros),objective_lower_bound=str(rhs),volume_lower_bound=str(rhs-1),elapsed_seconds=time.time()-start)
    (ROOT/'efv_audit_result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
